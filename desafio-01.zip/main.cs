using System;

class Program {
  public static void Main (string[] args) {
  Console.WriteLine ("digite o tempo de viagem");
    
    float tempo = float.Parse  (Console.ReadLine());
    Console.WriteLine ("digite a Velocidade");
    float Velocidade = float.Parse (Console.ReadLine());
    
    float Litros = (tempo * Velocidade) / 12;
    Litros = MathF.Round(Litros, 3);
    
    Console.WriteLine(Litros);
    
  }
}