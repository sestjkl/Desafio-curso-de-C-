using System;

class Program {
  public static void Main (string[] args) {
    Console.WriteLine ("digite o codigo do produto:");
    int codigo = int.Parse(Console.ReadLine());
    Console.WriteLine("digite a quantidade:");
    int quantidade = int.Parse(Console.ReadLine());
   
    int 2 = ("salada") = 4.50;
    int 3 = ("bacon") = 5.00;
    int 4 = ("torrada") = 2.00;
    int 5 = ("refrigerante") = 1.50;
    int 1 = ("cachorro_quente") = 4.00;
  }
}